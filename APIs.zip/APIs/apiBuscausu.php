<?php
header("Access-Control-Allow-Origin: *");
header('Content-Type: text/html; charset=utf-8');


setlocale(LC_ALL,'pt_BR.UTF8');
mb_internal_encoding('UTF8'); 
mb_regex_encoding('UTF8');


$data = file_get_contents("php://input");
$objData = json_decode($data);


$dns = 'mysql:host=localhost;dbname=maisa613_site;charset=utf8';
$user = 'maisa613_app';
$pass = 'EqS?eeOlSkyT';

$counter = $objData->counter;
$token = $objData->token;

try {	
	$con = new PDO($dns, $user, $pass);

	if(!$con){
		echo "Não foi possivel conectar com Banco de Dados!";
	}

	if ($token === "1f3d2gs3f2fg3as2fdg3re2t1we46er45" && isset($token)) {
		

	$query = $con->prepare('SELECT * FROM tb_usu');

		$query->execute();

		$out = "[";

		while($result = $query->fetch()){
			if ($out != "[") {
				$out .= ",";
			}
			$out .= '{"Id": "'.$result["Id"].'",';
			$out .= '"nome": "'.$result["nome"].'",';
			$out .= '"email": "'.$result["email"].'",';
			$out .= '"senha": "'.$result["senha"].'"}';
		}
		$out .= "]";
		echo $out;
	
	}

} catch (Exception $e) {
	echo "Erro: ". $e->getMessage();
};