<html>
	
    
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">
		
		<title>Resgatar senha - Mais Amor Cuidadores</title>
		
		<link href="css/styles.css" rel="stylesheet">
	</head>
	
	<body>
		<div class="login-page">
			<div class="retangulo">
				<div class="logobranco">
					<a href="http://www.maisamorcuidadores.com.br/" target="_blank"><img src="img/logo-maisamor.png" style="max-width: 300px; margin-bottom: 15px; margin-left: 5px; margin-right: 5px;" alt="Mais Amor Cuidadores"></a>
				</div>
				<div class="form">
                    <div><br/>Sua senha foi alterada com sucesso.<br/></div>
				</div>
			</div>
		</div>
	</body>
	
</html>














