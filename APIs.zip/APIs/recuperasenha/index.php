<?php;
header("Access-Control-Allow-Origin: *");
header('Content-Type: text/html; charset=utf-8');
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

setlocale(LC_ALL,'pt_BR.UTF8');
mb_internal_encoding('UTF8');
mb_regex_encoding('UTF8');

include("../apiBcrypt.php");

$data = file_get_contents("php://input");
$objData = json_decode($data);

$dns = 'mysql:host=localhost;dbname=maisa613_site;charset=utf8';
$user = 'maisa613_app';
$pass = 'EqS?eeOlSkyT';

$token = $_GET["token"];


	if($_SERVER["REQUEST_METHOD"] == "POST") {
		$senha = $_POST['senha'];
		$confirmasenha = $_POST['confirmasenha']; 
		if($token!="" && $senha!="" && $confirmasenha!="") {
			if($senha === $confirmasenha) {
				
				$hash = Bcrypt::hash($senha);
				
				$db = new PDO("mysql:host=localhost;dbname=maisa613_site;charset=utf8", "maisa613_app", "EqS?eeOlSkyT");
				if($db){
			        	$sql = "UPDATE tb_usu SET senha='".$hash."' WHERE senha='".$token."'";
			        	
					$query = $db->prepare($sql);
					$query ->execute();
						
					$mensagem = "Sua senha foi alterada com sucesso.";
					
					header("Location: http://www.maisamorcuidadores.com.br/app_maisamor/recuperasenha/sucesso.php");
					exit();
					
				} else {
					$mensagem = "Houve um erro, tente novamente mais tarde.";
				};
				
			} else {
				$mensagem = "Sua senha não é a mesma da confirmação, por favor tente novamente.";
			}
		}
	}
?>


<html>
	
    
	<head><meta http-equiv="Content-Type" content="text/html; charset=shift_jis">
		
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">
		
		<title>Resgatar senha - Mais Amor Cuidadores</title>
		
		<link href="css/styles.css" rel="stylesheet">
	</head>
	
	<body>
		<div class="login-page">
			<div class="retangulo">
				<div class="logobranco">
					<a href="http://www.maisamorcuidadores.com.br/" target="_blank"><img src="img/logo-maisamor.png" style="max-width: 300px; margin-bottom: 15px; margin-left: 5px; margin-right: 5px;" alt="Mais Amor Cuidadores"></a>
				</div>
				<div class="form">
					<form action = "" method = "post" id="Formulario" class="login-form">
						<input type="password" name = "senha" placeholder="Senha"/>
						<input type="password" name = "confirmasenha" placeholder="Confirma senha"/>
						<button>Salvar</button>
					</form>
					<div><br/><?php echo $mensagem; ?></div>
				</div>
			</div>
		</div>
	</body>
	
</html>














