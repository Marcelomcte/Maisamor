<?php
header("Access-Control-Allow-Origin:*");
header("Content-Type: application/html; charset=UTF-8");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

setlocale(LC_ALL,'pt_BR.UTF8');
mb_internal_encoding('UTF8'); 
mb_regex_encoding('UTF8');

    //formulário

    $data = file_get_contents("php://input");
    $objData = json_decode($data);

    // TRANSFORMA O S DADOS

    $id = $objData->id;
    $email = $objData->email;
    $servico = $objData->servico;
    $nome = $objData->nome;
    $nascimento = $objData->nascimento;
    $choice1 = $objData->choice1;
    //$diagnostico = $objData->diagnostico;
    $choice2 = $objData->choice2;
    $choice3 = $objData->choice3;
    $perfil_paciente = $objData->perfil_paciente;
    $perfil_cuidador = $objData->perfil_cuidador;
    $choice4 = $objData->choice4;
    $local = $objData->local;
    $ponto = $objData->ponto;
    $comentarios = $objData->comentarios;
    $choice5 = $objData->choice5;
    $choice6 = $objData->choice6;
    $choice7 = $objData->choice7;
    $choice8 = $objData->choice8;
    $choice9 = $objData->choice9;
    $choice10 = $objData->choice10;
    $choice11 = $objData->choice11;
    $choice12 = $objData->choice12;
    $choice13 = $objData->choice13;
    $choice14 = $objData->choice14;
    $choice15 = $objData->choice15;
    $choice16 = $objData->choice16;
    $choice17 = $objData->choice17;
    $choice18 = $objData->choice18;
    $choice19 = $objData->choice19;
    $dataprevista = $objData->dataprevista;
    $condicao = $objData->condicao;
    $cuidado = $objData->cuidado;
    $limitacao = $objData->limitacao;
    $atividadeespecifica = $objData->atividadeespecifica;
    $gestacao = $objData->gestacao;
    $risco = $objData->risco;
    $crianca = $objData->crianca;
    $patologia = $objData->patologia;
    $necessidadeespecifica = $objData->necessidadeespecifica;
    $bebe = $objData->bebe;
    $telefone = $objData->telefone;

    // LIMPA OS DADOS

    $id = stripslashes($id);
    $email = stripslashes($email);
    $servico = stripslashes($servico);
    $nome = stripslashes($nome);
    $nascimento = stripslashes($nascimento);
    $choice1 = stripslashes($choice1);
    $diagnostico = stripslashes($diagnostico);
    $choice2 = stripslashes($choice2);
    $choice3 = stripslashes($choice3);
    $perfil_paciente = stripslashes($perfil_paciente);
    $perfil_cuidador = stripslashes($perfil_cuidador);
    $choice4 = stripslashes($choice4);
    $local = stripslashes($local);
    $ponto = stripslashes($ponto);
    $comentarios = stripslashes($comentarios);
    $choice5 = stripslashes($choice5);
    $choice6 = stripslashes($choice6);
    $choice7 = stripslashes($choice7);
    $choice8 = stripslashes($choice8);
    $choice9 = stripslashes($choice9);
    $choice10 = stripslashes($choice10);
    $choice11 = stripslashes($choice11);
    $choice12 = stripslashes($choice12);
    $choice13 = stripslashes($choice13);
    $choice14 = stripslashes($choice14);
    $choice15 = stripslashes($choice15);
    $choice16 = stripslashes($choice16);
    $choice17 = stripslashes($choice17);
    $choice18 = stripslashes($choice18);
    $choice19 = stripslashes($choice19);
    $dataprevista = stripslashes($dataprevista);
    $condicao = stripslashes($condicao);
    $cuidado = stripslashes($cuidado);
    $limitacao = stripslashes($limitacao);
    $atividadeespecifica = stripslashes($atividadeespecifica);
    $gestacao = stripslashes($gestacao);
    $risco = stripslashes($risco);
    $crianca = stripslashes($crianca);
    $patologia = stripslashes($patologia);
    $necessidadeespecifica = stripslashes($necessidadeespecifica);
    $bebe = stripslashes($bebe);
    $telefone = stripslashes($telefone);

    $id = trim($id);
    $email = trim($email);
    $servico = trim($servico);
    $nome = trim($nome);
    $nascimento = trim($nascimento);
    $choice1 = trim($choice1);
    $diagnostico = trim($diagnostico);
    $choice2 = trim($choice2);
    $choice3 = trim($choice3);
    $perfil_paciente = trim($perfil_paciente);
    $perfil_cuidador = trim($perfil_cuidador);
    $choice4 = trim($choice4);
    $local = trim($local);
    $ponto = trim($ponto);
    $comentarios = trim($comentarios);
    $choice5 = trim($choice5);
    $choice6 = trim($choice6);
    $choice7 = trim($choice7);
    $choice8 = trim($choice8);
    $choice9 = trim($choice9);
    $choice10 = trim($choice10);
    $choice11 = trim($choice11);
    $choice12 = trim($choice12);
    $choice13 = trim($choice13);
    $choice14 = trim($choice14);
    $choice15 = trim($choice15);
    $choice16 = trim($choice16);
    $choice17 = trim($choice17);
    $choice18 = trim($choice18);
    $choice19 = trim($choice19);
    $dataprevista = trim($dataprevista);
    $condicao = trim($condicao);
    $cuidado = trim($cuidado);
    $limitacao = trim($limitacao);
    $atividadeespecifica = trim($atividadeespecifica);
    $gestacao = trim($gestacao);
    $risco = trim($risco);
    $crianca = trim($crianca);
    $patologia = trim($patologia);
    $necessidadeespecifica = trim($necessidadeespecifica);
    $bebe = trim($bebe);
    $telefone = trim($telefone);

    $interditado = "";
    if ($choice4 != false){
    	$interditado = "Sim";
    } else {
        $interditado = "Não";
    };



    if($choice5 == false){
        $patologia_todo = "Não";
    } else {
        $patologia_todo = "Sim";
    }
                
    if($choice11 == false){
        $necessidade_adulto = "Não";
    } else {
        $necessidade_adulto = "Sim";
    }
                
    if($choice12 == false){
        $limitacao_adulto = "Não";
    } else {
        $limitacao_adulto = "Sim";
    }
                
    if($choice13 == false){
        $atividade_adulto = "Não";
    } else {
        $atividade_adulto = "Sim";
    }
                
    if($choice14 == false){
        $gestacao_ultimo = "Não";
    } else {
        $gestacao_ultimo = "Sim";
    }
                
    if($choice15 == false){
        $risco_gestacao_ultimo = "Não";
    } else {
        $risco_gestacao_ultimo = "Sim";
    }
                
    if($choice16 == false){
        $cuidados_crianca = "Não";
    } else {
        $cuidados_crianca = "Sim";
    }
                
    if($choice18 == false){
        $disturbio_crianca = "Não";
    } else {
        $disturbio_crianca = "Sim";
    }
                
    if($choice19 == false){
        $necessidade_crianca = "Não";
    } else {
        $necessidade_crianca = "Sim";
    }

    if($choice17 == false){
        $cuidados_bebe = "Não";
    } else {
        $cuidados_bebe = "Sim";
    }

    // INSERE OS DADOS
	$db = new PDO("mysql:host=localhost;dbname=maisa613_site;charset=utf8", "maisa613_app", "EqS?eeOlSkyT");
	
	if($db){
		$sql = "INSERT INTO tb_solicitacao_servicos (data_pedido, id_requerente, email, servico_solicitado, nome_paciente, nascimento, genero, diagnostico, deambulacao, alimentacao, perfil_paciente, perfil_cuidador, interditado, local, ponto, comentarios, cancelado, telefone, gestacao, condicao, cuidado, limitacao, atividadeespecifica, risco, crianca, patologia, necessidadeespecifica, bebe, dataprevista, pref_genero, dias_do_cuidador, horas_do_cuidador, atividade_idosos, turno, cuidados_especiais_adultos, limitacao_motora_adultos, atividade_adultos, cuidados_com_gestantes, gravidez_de_risco, cuidados_com_criancas, cuidados_com_bebes, alguma_patologia_crianca, necessidade_especifica_crianca, patologia_todos) VALUES (NOW(), ".$id.", '".$email."', '".$servico."', '".$nome."', '".$nascimento."', '".$choice1."', '".$diagnostico."', '".$choice2."', '".$choice3."', '".$perfil_paciente."', '".$perfil_cuidador."', '".$interditado."', '".$local."', '".$ponto."', '".$comentarios."','N', '".$telefone."', '".$gestacao."', '".$condicao."', '".$cuidado."', '".$limitacao."', '".$atividadeespecifica."', '".$risco."', '".$crianca."', '".$patologia."', '".$necessidadeespecifica."', '".$bebe."', '".$dataprevista."', '".$choice6."', '".$choice7."', '".$choice8."', '".$choice9."', '".$choice10."', '".$necessidade_adulto."', '".$limitacao_adulto."', '".$atividade_adulto."', '".$gestacao_ultimo."', '".$risco_gestacao_ultimo."', '".$cuidados_crianca."', '".$cuidados_bebe."', '".$disturbio_crianca."', '".$necessidade_crianca."', '".$patologia_todo."')";
        
        if ($nome!=''){
            $query = $db->prepare($sql);
            $query ->execute();
            if(!$query){
                $dados = array('mensage' => "Não foi possível enviar os dados.");
                echo json_encode($dados);
            } else {
						
                $date = new DateTime($nascimento);
                $datajunta = $date->format('d-m-Y');
                $date2 = new DateTime($dataprevista);
                $datajunta2 = $date2->format('d-m-Y');
                

                
                if ($servico == "Cuidadores de Idosos com Dependência de Saúde"){
                    $msg = "
                        <html>
                            <head>
                                <title>Solicite um Serviço</title>
                            </head>
                            <body>
                                <p><b>Serviço solicitado: </b>".$servico."</p>
                                <p><b>E-mail: </b>".$email."</p>
                                <p><b>Telefone do responsável: </b>".$telefone."</p>
                                <p><b>Nome do assistido: </b>".$nome."</p>
                                <p><b>Data de nascimento do paciente: </b>".$datajunta."</p>
                                <p><b>Gênero do paciente: </b>".$choice1."</p>
                                <p><b>Deambulação: </b> ".$choice2."</p>
                                <p><b>Alimentação: </b> ".$choice3."</p>
                                <p><b>Perfil do assistido: </b> ".$perfil_paciente."</p>
                                <p><b>Existência de patologia ou doença crônica: </b> ".$patologia_todo."</p>
                                <p><b>Condição patológica ou doença crônica: </b> ".$condicao."</p>
                                <p><b>Perfil do cuidador: </b> ".$perfil_cuidador."</p>
                                <p><b>Preferência por gênero: </b> ".$choice6."</p>
                                <p><b>Necessidade de utilização do cuidador: </b> ".$choice7." / ".$choice8."</p>
                                <p><b>Interditado judicialmente: </b> ".$interditado."</p>
                                <p><b>Local de prestação do serviço: </b> ".$local."</p>
                                <p><b>Ponto de referência: </b> ".$ponto."</p>
                                <p><b>Informações adicionais importantes: </b> ".$comentarios."</p>
                            </body>
                        </html>
                ";
                } elseif($servico == "Cuidadores Acompanhantes"){
                    $msg = "
                        <html>
                            <head>
                                <title>Solicite um Serviço</title>
                            </head>
                            <body>
                                <p><b>Serviço solicitado: </b>".$servico."</p>
                                <p><b>E-mail: </b>".$email."</p>
                                <p><b>Telefone do responsável: </b>".$telefone."</p>
                                <p><b>Nome do assistido: </b>".$nome."</p>
                                <p><b>Data de nascimento do paciente: </b>".$datajunta."</p>
                                <p><b>Gênero do paciente: </b>".$choice1."</p>
                                <p><b>Deambulação: </b> ".$choice2."</p>
                                <p><b>Perfil do assistido: </b> ".$perfil_paciente."</p>
                                <p><b>Existência de patologia ou doença crônica: </b> ".$patologia_todo."</p>
                                <p><b>Condição patológica ou doença crônica: </b> ".$condicao."</p>
                                <p><b>Atividade que o assistido vai necessitar da companhia do cuidador: </b> ".$choice9."</p>
                                <p><b>Data prevista para prestação do serviço: </b> ".$datajunta2."</p>
                                <p><b>Turno: </b> ".$choice10."</p>
                                <p><b>Perfil do cuidador: </b> ".$perfil_cuidador."</p>
                                <p><b>Preferência por gênero: </b> ".$choice6."</p>
                                <p><b>Local de prestação do serviço: </b> ".$local."</p>
                                <p><b>Ponto de referência: </b> ".$ponto."</p>
                                <p><b>Informações adicionais importantes: </b> ".$comentarios."</p>
                            </body>
                        </html>
                ";
                } elseif($servico == "Cuidadores de Adultos"){
                    $msg = "
                        <html>
                            <head>
                                <title>Solicite um Serviço</title>
                            </head>
                            <body>
                                <p><b>Serviço solicitado: </b>".$servico."</p>
                                <p><b>E-mail: </b>".$email."</p>
                                <p><b>Telefone do responsável: </b>".$telefone."</p>
                                <p><b>Nome do assistido: </b>".$nome."</p>
                                <p><b>Data de nascimento do paciente: </b>".$datajunta."</p>
                                <p><b>Gênero do paciente: </b>".$choice1."</p>
                                <p><b>Deambulação: </b> ".$choice2."</p>
                                <p><b>Alimentação: </b> ".$choice3."</p>
                                <p><b>Necessidade de cuidados especiais: </b> ".$necessidade_adulto.", ".$cuidado." </p>
                                <p><b>Limitação motora: </b> ".$limitacao_adulto.", ".$limitacao." </p>
                                <p><b>Atividade específica demandada do cuidador: </b> ".$atividade_adulto.", ".$atividadeespecifica." </p>
                                <p><b>Perfil do assistido: </b> ".$perfil_paciente."</p>
                                <p><b>Existência de patologia ou doença crônica: </b> ".$patologia_todo."</p>
                                <p><b>Condição patológica ou doença crônica: </b> ".$condicao."</p>
                                <p><b>Perfil do cuidador: </b> ".$perfil_cuidador."</p>
                                <p><b>Preferência por gênero: </b> ".$choice6."</p>
                                <p><b>Necessidade de utilização do cuidador: </b> ".$choice7." / ".$choice8."</p>
                                <p><b>Interditado judicialmente: </b> ".$interditado."</p>
                                <p><b>Local de prestação do serviço: </b> ".$local."</p>
                                <p><b>Ponto de referência: </b> ".$ponto."</p>
                                <p><b>Informações adicionais importantes: </b> ".$comentarios."</p>
                            </body>
                        </html>
                ";
                } elseif($servico == "Cuidadores de Crianças e Gestantes"){
                    $msg = "
                        <html>
                            <head>
                                <title>Solicite um Serviço</title>
                            </head>
                            <body>
                                <p><b>Serviço solicitado: </b>".$servico."</p>
                                <p><b>E-mail: </b>".$email."</p>
                                <p><b>Telefone do responsável: </b>".$telefone."</p>
                                <p><b>Nome do assistido: </b>".$nome."</p>
                                <p><b>Data de nascimento do paciente: </b>".$datajunta."</p>
                                <p><b>Gênero do paciente: </b>".$choice1."</p>
                                <p><b>Cuidados com gestantes: </b> ".$gestacao_ultimo.", ".$gestacao." </p>
                                <p><b>Gravidez de risco: </b> ".$risco_gestacao_ultimo.", ".$risco." </p>
                                <p><b>Cuidados com crianças: </b> ".$cuidados_crianca.", ".$crianca." </p>
                                <p><b>Patologia, distúrbio ou síndrome: </b> ".$disturbio_crianca.", ".$patologia." </p>
                                <p><b>Cuidado ou necessidade específica: </b> ".$necessidade_crianca.", ".$necessidadeespecifica." </p>
                                <p><b>Cuidados com recém-nascidos: </b> ".$cuidados_bebe.", ".bebe." </p>
                                <p><b>Perfil do assistido: </b> ".$perfil_paciente."</p>
                                <p><b>Existência de patologia ou doença crônica: </b> ".$patologia_todo."</p>
                                <p><b>Condição patológica ou doença crônica: </b> ".$condicao."</p>
                                <p><b>Perfil do cuidador: </b> ".$perfil_cuidador."</p>
                                <p><b>Preferência por gênero: </b> ".$choice6."</p>
                                <p><b>Necessidade de utilização do cuidador: </b> ".$choice7." / ".$choice8."</p>
                                <p><b>Interditado judicialmente: </b> ".$interditado."</p>
                                <p><b>Local de prestação do serviço: </b> ".$local."</p>
                                <p><b>Ponto de referência: </b> ".$ponto."</p>
                                <p><b>Informações adicionais importantes: </b> ".$comentarios."</p>
                            </body>
                        </html>
                ";
                } else {
                    
                }
                
                
				$headers = "Content-Type: text/html; charset=UTF-8;"."\r\n"."From: contato@maisamorcuidadores.com.br";
				@mail("alissonfreitas3381@hotmail.com", '=?utf-8?B?'.base64_encode('Solicitação de Serviço - '.$servico.'').'?=', $msg, $headers);
				//contato@maisamorcuidadores.com.br
			
			
				$dados = array('mensage' => "O seus dados foram enviados com sucesso. Obrigado e a equipe Mais Amor Cuidadores entrará em contato!");
				echo json_encode($dados);
			};
		}	
	} else {
		$dados = array('mensage' => "Não foi possível inserir os dados! Tente novamente mais tarde.");
		echo json_encode($dados);
	};
