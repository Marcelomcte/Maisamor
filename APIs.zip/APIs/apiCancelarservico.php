<?php
header("Access-Control-Allow-Origin:*");
header("Content-Type: application/html; charset=UTF-8");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

setlocale(LC_ALL,'pt_BR.UTF8');
mb_internal_encoding('UTF8'); 
mb_regex_encoding('UTF8');

    //formulário

    $data = file_get_contents("php://input");
    $objData = json_decode($data);
    

    $id = $objData->id;
    $id = stripslashes($id);
    $id = trim($id);

 

    // INSERE OS DADOS
	$db = new PDO("mysql:host=localhost;dbname=maisa613_site;charset=utf8", "maisa613_app", "EqS?eeOlSkyT");

	if($db){
		$sql = "UPDATE tb_solicitacao_servicos SET cancelado='Y' WHERE Id=".$id."";
        
        $query = $db->prepare($sql);
        $query ->execute();
        if(!$query){
            $dados = array('mensage' => "Não foi possível enviar os dados");
            echo json_encode($dados);
        } else {
            $dados = array('mensage' => "Sua solicitação foi cancelada com sucesso");
            echo json_encode($dados);
        };
		
	} else {
		$dados = array('mensage' => "Não foi possível inserir os dados! Tente novamente mais tarde.");
		echo json_encode($dados);
	};






















