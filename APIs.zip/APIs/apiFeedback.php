<?php
header("Access-Control-Allow-Origin:*");
header("Content-Type: application/html; charset=UTF-8");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

setlocale(LC_ALL,'pt_BR.UTF8');
mb_internal_encoding('UTF8'); 
mb_regex_encoding('UTF8');

    //formulário

    $data = file_get_contents("php://input");
    $objData = json_decode($data);

    // TRANSFORMA OS DADOS
    
    $nome = $objData->nome;
    $email = $objData->email;
    $telefone = $objData->telefone;
    $comentarios = $objData->comentarios;

    // LIMPA OS DADOS

    $nome = stripslashes($nome);
    $email = stripslashes($email);
    $telefone = stripslashes($telefone);
    $comentarios = stripslashes($comentarios);

    $nome = trim($nome);
    $email = trim($email);
    $telefone = trim($telefone);
    $comentarios = trim($comentarios);


    // INSERE OS DADOS
	$db = new PDO("mysql:host=localhost;dbname=maisa613_site;charset=utf8", "maisa613_app", "EqS?eeOlSkyT");

	if($db){
		$sql = "INSERT INTO contato (nome, email, telefone, mensagem) VALUES ('".$nome."', '".$email."', '".$telefone."', '".$comentarios."')";
		if ($nome!=''){
			$query = $db->prepare($sql);
			$query ->execute();
			if(!$query){
				$dados = array('mensage' => "Não foi possível enviar os dados");
				echo json_encode($dados);
			} else {
				$dados = array('mensage' => "As informações foram enviadas com sucesso. A equipe Mais Amor Cuidadores agradece.");
				echo json_encode($dados);
			};
		}
	} else {
		$dados = array('mensage' => "Não foi possível enviar os dados! Tente novamente mais tarde.");
		echo json_encode($dados);
	};






















