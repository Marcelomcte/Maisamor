<?php
header("Access-Control-Allow-Origin:*");
header("Content-Type: application/html; charset=UTF-8");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

setlocale(LC_ALL,'pt_BR.UTF8');
mb_internal_encoding('UTF8'); 
mb_regex_encoding('UTF8');

    //formulário

    $data = file_get_contents("php://input");
    $objData = json_decode($data);

    // TRANSFORMA O S DADOS
    $id = $objData->id;
    $email = $objData->email;
    
    $servico = $objData->servico;

    $nome = $objData->nome;
    $nascimento = $objData->nascimento;

    $choice1 = $objData->choice1;

    $diagnostico = $objData->diagnostico;

    $choice2 = $objData->choice2;

    $choice3 = $objData->choice3;

    $perfil_paciente = $objData->perfil_paciente;
    $perfil_cuidador = $objData->perfil_cuidador;

    $choice4 = $objData->choice4;

    $local = $objData->local;
    $ponto = $objData->ponto;

    $comentarios = $objData->comentarios;

    // LIMPA OS DADOS

    $id = stripslashes($id);
    $email = stripslashes($email);
    $servico = stripslashes($servico);
    $nome = stripslashes($nome);
    $nascimento = stripslashes($nascimento);
    $choice1 = stripslashes($choice1);
    $diagnostico = stripslashes($diagnostico);
    $choice2 = stripslashes($choice2);
    $choice3 = stripslashes($choice3);
    $perfil_paciente = stripslashes($perfil_paciente);
    $perfil_cuidador = stripslashes($perfil_cuidador);
    $choice4 = stripslashes($choice4);
    $local = stripslashes($local);
    $ponto = stripslashes($ponto);
    $comentarios = stripslashes($comentarios);


    $id = trim($id);
    $email = trim($email);
    $servico = trim($servico);
    $nome = trim($nome);
    $nascimento = trim($nascimento);
    $choice1 = trim($choice1);
    $diagnostico = trim($diagnostico);
    $choice2 = trim($choice2);
    $choice3 = trim($choice3);
    $perfil_paciente = trim($perfil_paciente);
    $perfil_cuidador = trim($perfil_cuidador);
    $choice4 = trim($choice4);
    $local = trim($local);
    $ponto = trim($ponto);
    $comentarios = trim($comentarios);


    $interditado = "";
    if ($choice4 != false){
    	$interditado = "Sim";
    } else {
        $interditado = "Não";
    };




    // INSERE OS DADOS
	$db = new PDO("mysql:host=localhost;dbname=maisa613_site;charset=utf8", "maisa613_app", "EqS?eeOlSkyT");
	
	if($db){
		$sql = "INSERT INTO tb_solicitacao_servicos (data_pedido, id_requerente, email, servico_solicitado, nome_paciente, nascimento, genero, diagnostico, deambulacao, alimentacao, perfil_paciente, perfil_cuidador, interditado, local, ponto, comentarios, cancelado) VALUES (NOW(), ".$id.", '".$email."', '".$servico."', '".$nome."', '".$nascimento."', '".$choice1."', '".$diagnostico."', '".$choice2."', '".$choice3."', '".$perfil_paciente."', '".$perfil_cuidador."', '".$interditado."', '".$local."', '".$ponto."', '".$comentarios."','N')";
        	if ($nome!=''){
			$query = $db->prepare($sql);
			$query ->execute();
			if(!$query){
				$dados = array('mensage' => "Não foi possível enviar os dados.");
				echo json_encode($dados);
			} else {
			
				
				$date = new DateTime($nascimento);
				$datajunta = $date->format('d-m-Y');
			
				$msg = "
					<html>
						<head>
							<title>Solicite um Serviço</title>
						</head>
						<body>
							<p><b>E-mail: </b>".$email."</p>
							<p><b>Nome do Paciente: </b>".$nome."</p>
							<p><b>Serviço solicitado: </b>".$servico."</p>
							<p><b>Data de nascimento do paciente: </b>".$datajunta."</p>
							<p><b>Gênero do paciente: </b>".$choice1."</p>
							<p><b>Diagnóstico: </b>".$diagnostico."</p>
							<p><b>Deambulação: </b> ".$choice2."</p>
							<p><b>Alimentação: </b> ".$choice3."</p>
							<p><b>Perfil do Paciente: </b> ".$perfil_paciente."</p>
							<p><b>Perfil do Cuidador: </b> ".$perfil_cuidador."</p>
							<p><b>Interditado Judicialmente: </b> ".$interditado."</p>
							<p><b>Local de prestação do serviço: </b> ".$local."</p>
							<p><b>Ponto de referência: </b> ".$ponto."</p>
							<p><b>Comentários: </b> ".$comentarios."</p>
						</body>
					</html>
				";
				$headers = "Content-Type: text/html; charset=UTF-8;"."\r\n"."From: contato@maisamorcuidadores.com.br";
				@mail("contato@maisamorcuidadores.com.br", '=?utf-8?B?'.base64_encode('Solicitação de Serviço - '.$servico.'').'?=', $msg, $headers);
				//contato@maisamorcuidadores.com.br
			
			
				$dados = array('mensage' => "O seus dados foram enviados com sucesso. Obrigado e a equipe Mais Amor Cuidadores entrará em contato!");
				echo json_encode($dados);
			};
		}	
	} else {
		$dados = array('mensage' => "Não foi possível inserir os dados! Tente novamente mais tarde.");
		echo json_encode($dados);
	};