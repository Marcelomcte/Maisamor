<?php
header("Access-Control-Allow-Origin:*");
header("Content-Type: application/html; charset=UTF-8");

setlocale(LC_ALL,'pt_BR.UTF8');
mb_internal_encoding('UTF8'); 
mb_regex_encoding('UTF8');

    //formulário

    $data = file_get_contents("php://input");
    $objData = json_decode($data);

    // TRANSFORMA O S DADOS
    $id = $objData->id;
    $email = $objData->email;
    
    $solicitado = $objData->solicitado;

    $nome = $objData->nome;
    $nascimento = $objData->nascimento;

    $choice1 = $objData->choice1;

    $diagnostico = $objData->diagnostico;

    $choice2 = $objData->choice2;

    $choice3 = $objData->choice3;

    $perfil_paciente = $objData->perfil_paciente;
    $perfil_cuidador = $objData->perfil_cuidador;

    $choice4 = $objData->choice4;

    $local = $objData->local;
    $ponto = $objData->ponto;

    $comentarios = $objData->comentarios;

    // LIMPA OS DADOS

    $id = stripslashes($id);
    $email = stripslashes($email);
    $solicitado = stripslashes($solicitado);
    $nome = stripslashes($nome);
    $nascimento = stripslashes($nascimento);
    $choice1 = stripslashes($choice1);
    $diagnostico = stripslashes($diagnostico);
    $choice2 = stripslashes($choice2);
    $choice3 = stripslashes($choice3);
    $perfil_paciente = stripslashes($perfil_paciente);
    $perfil_cuidador = stripslashes($perfil_cuidador);
    $choice4 = stripslashes($choice4);
    $local = stripslashes($local);
    $ponto = stripslashes($ponto);
    $comentarios = stripslashes($comentarios);


    $id = trim($id);
    $email = trim($email);
    $solicitado = trim($solicitado);
    $nome = trim($nome);
    $nascimento = trim($nascimento);
    $choice1 = trim($choice1);
    $diagnostico = trim($diagnostico);
    $choice2 = trim($choice2);
    $choice3 = trim($choice3);
    $perfil_paciente = trim($perfil_paciente);
    $perfil_cuidador = trim($perfil_cuidador);
    $choice4 = trim($choice4);
    $local = trim($local);
    $ponto = trim($ponto);
    $comentarios = trim($comentarios);



    // INSERE OS DADOS
    $db = new PDO("mysql:host=localhost;dbname=maisa613_site;charset=utf8", "maisa613_app", "EqS?eeOlSkyT");


    if($db){
        
        $sql = "INSERT INTO tb_solicitacao_servicos (data_pedido, id_requerente, email, servico_solicitado, nome_paciente, nascimento, genero, diagnostico, deambulacao, alimentacao, perfil_paciente, perfil_cuidador, interditado, local, ponto, comentarios) VALUES (NOW(), ".$id.", '".$email."', '".$solicitado."', '".$nome."', '".$nascimento."', '".$choice1."', '".$diagnostico."', '".$choice2."', '".$choice3."', '".$perfil_paciente."', '".$perfil_cuidador."', '".$choice4."', '".$local."', '".$ponto."', '".$comentarios."')";
        
        
        $query = $db->prepare($sql);
        $query ->execute();
        echo "O seus dados foram enviados com sucesso. Obrigado e a equipe Mais Amor Cuidadores entrará em contato!";
    }else{
        echo "Não foi possível inserir os dados! Tente novamente mais tarde.";
    };