<?php
header("Access-Control-Allow-Origin: *");
header('Content-Type: text/html; charset=utf-8');
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

setlocale(LC_ALL,'pt_BR.UTF8');
mb_internal_encoding('UTF8'); 
mb_regex_encoding('UTF8');

$data = file_get_contents("php://input");
$objData = json_decode($data);

$dns = 'mysql:host=localhost;dbname=maisa613_site;charset=utf8';
$user = 'maisa613_app';
$pass = 'EqS?eeOlSkyT';

$email = $objData->email;

try {
	$con = new PDO($dns, $user, $pass);
	
	if(!$con){
		echo "Não foi possivel conectar com Banco de Dados!";
	};

	$query = $con->prepare("SELECT * FROM tb_usu WHERE email = '".$email."'");
	$query->execute();
	$result = $query->fetch();
	
	
	$nome = $result['nome'];
	$senha = $result['senha'];
  
	$msg = "
        	<html>
			<head>
				<title>Recuperação de senha Mais Amor Cuidadores</title>
			</head>
			<body>
				<p>Olá <b>".$nome."</b> se você está recebendo este email é porque está tentando mudar a senha da sua conta, caso não tenha solicitado isso desconsidere este email.</p>
				<p><b>Acesse este link para redefinir a senha: </b><a href='www.maisamorcuidadores.com.br/app_maisamor/recuperasenha/index.php?token=".$senha."'>Link</a></p>
			</body>
		</html>
	";

	$headers = "Content-Type: text/html; charset=UTF-8;"."\r\n"."From: recuperasenha@maisamorcuidadores.com.br";
	@mail($email, '=?utf-8?B?'.base64_encode('Recuperação de senha Mais Amor Cuidadores').'?=', $msg, $headers);
	
	
	
	
	
	
	
    
	if(!$query){
		$dados = array('mensage' => "Não foi possível enviar os dados");
		echo json_encode($dados);
	} else {
		$dados = array('mensage' => "O email foi enviado com sucesso, aguarde alguns instantes e lembre-se de checar seu filtro de span e lixeira eletrônica. A equipe Mais Amor Cuidadores agradece.");
		echo json_encode($dados);
	};
    
} catch (Exception $e) {
	echo "Erro: ". $e->getMessage();
};