<?php
header("Access-Control-Allow-Origin:*");
header("Content-Type: application/html; charset=UTF-8");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

setlocale(LC_ALL,'pt_BR.UTF8');
mb_internal_encoding('UTF8'); 
mb_regex_encoding('UTF8');

    //formulário

    $data = file_get_contents("php://input");
    $objData = json_decode($data);

    // TRANSFORMA OS DADOS
    
    $nome = $objData->nome;
    $email = $objData->email;
    $telefone = $objData->telefone;

    $criancas = $objData->criancas;
    $adultos = $objData->adultos;
    $idosos = $objData->idosos;

    $manha = $objData->manha;
    $tarde = $objData->tarde;
    $noite = $objData->noite;
    $integral = $objData->integral;

    $escolha1 = $objData->escolha1;

    $escolha2 = $objData->escolha2;
    $formacao = $objData->formacao;

    $escolha3 = $objData->escolha3;
    $instituicao = $objData->instituicao;

    $escolha4 = $objData->escolha4;
    $empresa = $objData->empresa;


    // LIMPA OS DADOS

    $nome = stripslashes($nome);
    $email = stripslashes($email);
    $telefone = stripslashes($telefone);
    $criancas = stripslashes($criancas);
    $adultos = stripslashes($adultos);
    $idosos = stripslashes($idosos);
    $manha = stripslashes($manha);
    $tarde = stripslashes($tarde);
    $noite = stripslashes($noite);
    $integral = stripslashes($integral);
    $escolha1 = stripslashes($escolha1);
    $escolha2 = stripslashes($escolha2);
    $formacao = stripslashes($formacao);
    $escolha3 = stripslashes($escolha3);
    $instituicao = stripslashes($instituicao);
    $escolha4 = stripslashes($escolha4);
    $empresa = stripslashes($empresa);

    $nome = trim($nome);
    $email = trim($email);
    $telefone = trim($telefone);
    $criancas = trim($criancas);
    $adultos = trim($adultos);
    $idosos = trim($idosos);
    $manha = trim($manha);
    $tarde = trim($tarde);
    $noite = trim($noite);
    $integral = trim($integral);
    $escolha1 = trim($escolha1);
    $escolha2 = trim($escolha2);
    $formacao = trim($formacao);
    $escolha3 = trim($escolha3);
    $instituicao = trim($instituicao);
    $escolha4 = trim($escolha4);
    $empresa = trim($empresa);
    
    $deseja = "";
    if (($criancas != false) and ($adultos != false) and ($idosos != false)){
        $deseja = "Crianças com necessidades especiais, Adultos com limitação de mobilidade, Idosos com qualquer necessidade.";
    } else if (($criancas != false) and ($adultos != false)){
        $deseja = "Crianças com necessidades especiais, Adultos com limitação de mobilidade.";
    } else if (($adultos != false) and ($idosos != false)){
        $deseja = "Adultos com limitação de mobilidade, Idosos com qualquer necessidade.";
    } else if (($criancas != false) and ($idosos != false)){
        $deseja = "Crianças com necessidades especiais, Idosos com qualquer necessidade.";
    } else if (($criancas != false)){
        $deseja = "Crianças com necessidades especiais.";
    } else if (($adultos != false)){
        $deseja = "Adultos com limitação de mobilidade.";
    } else if (($idosos != false)){
        $deseja = "Idosos com qualquer necessidade.";
    } else{
        $deseja = "Inválido";
    };


    $horario = "";
    if (($manha != false) and ($tarde != false) and ($noite != false) and ($integral != false)){
	$horario = "Manhã, Tarde, Noite, Turno Integral.";
    } else if (($manha != false) and ($tarde != false) and ($noite != false)){
	$horario = "Manhã, Tarde, Noite.";
    } else if (($manha != false) and ($tarde != false) and ($integral != false)){
	$horario = "Manhã, Tarde, Turno Integral.";
    } else if (($manha != false) and ($noite != false) and ($integral != false)){
	$horario = "Manhã, Noite, Turno Integral.";
    } else if (($tarde != false) and ($noite != false) and ($integral != false)){
	$horario = "Tarde, Noite, Turno Integral.";
    } else if (($manha != false) and ($tarde != false)){
	$horario = "Manhã, Tarde.";
    } else if (($manha != false) and ($noite != false)){
	$horario = "Manhã, Noite.";
    } else if (($manha != false) and ($integral != false)){
	$horario = "Manhã, Turno Integral.";
    } else if (($tarde != false) and ($noite != false)){
	$horario = "Tarde, Noite.";
    } else if (($tarde != false) and ($integral != false)){
	$horario = "Tarde, Turno Integral.";
    } else if (($noite != false) and ($integral != false)){
	$horario = "Noite, Turno Integral.";
    } else if (($manha != false)){
	$horario = "Manhã.";
    } else if (($tarde != false)){
	$horario = "Tarde.";
    } else if (($noite != false)){
	$horario = "Noite.";
    } else if (($integral != false)){
	$horario = "Turno Integral.";
    } else{
        $horario = "Inválido";
    };

    
    $formacaonaarea = "";
    if ($escolha2 != false){
    	$formacaonaarea = "Cuidador de pessoas COM formação na área de saúde";    
    } else {
        $formacaonaarea = "Cuidador de pessoas SEM formação na área de saúde";    
    };
    
    
    $cursodecuidador = "";
    if ($escolha3 != false){
    	$cursodecuidador = "Sim";    
    } else {
        $cursodecuidador = "Não";    
    };



    // INSERE OS DADOS
	$db = new PDO("mysql:host=localhost;dbname=maisa613_site;charset=utf8", "maisa613_app", "EqS?eeOlSkyT");

	if($db){
		$sql = "INSERT INTO cadastro_cuidadores (nome, email, telefone, deseja, experiencia, horario, formacao, formacao_txt, curso, instituicao, exp_cuidador, empresa_exp) VALUES ('".$nome."', '".$email."', '".$telefone."', '".$deseja."', '".$escolha1."', '".$horario."', '".$formacaonaarea."', '".$formacao."', '".$cursodecuidador."', '".$instituicao."', '".$escolha4."', '".$empresa."')";
		if ($nome!=''){
			$query = $db->prepare($sql);
			$query ->execute();
			if(!$query){
				$dados = array('mensage' => "Não foi possível enviar os dados");
				echo json_encode($dados);
			} else {		
				$msg = "
					<html>
						<head>
							<title>Trabalhe conosco</title>
						</head>
						<body>
							<p><b>Nome: </b>".$nome."</p><br>
							<p><b>E-mail: </b>".$email."</p><br>
							<p><b>Telefone: </b>".$telefone."</p><br>
							<p><b>Deseja cuidar de: </b>".$deseja."</p><br>
							<p><b>Horário disponível para trabalho: </b>".$horario."</p>
							<p><b>Formação: </b>".$formacaonaarea."<br><b>Qual a formação?</b> ".$formacao."</p><br>
							<p><b>Experiência comprovada com trabalho remunerado: </b> ".$escolha1."</p><br>
							<p><b>Tem curso de cuidador de pessoas? </b>".$cursodecuidador."<br><b>Instituição:</b> ".$instituicao."</p><br>
							<p><b>Já trabalhou como cuidador?: </b>".$escolha4."<br><b>Na(s) empresa(s):</b> ".$empresa."</p><br>
						</body>
					</html>
				";
				$headers = "Content-Type: text/html; charset=UTF-8;"."\r\n"."From: contato@maisamorcuidadores.com.br";
				@mail("contato@maisamorcuidadores.com.br", '=?utf-8?B?'.base64_encode('Inscrição - Trabalhe conosco').'?=', $msg, $headers);
				//contato@maisamorcuidadores.com.br
			
			
				$dados = array('mensage' => "O seus dados foram enviados com sucesso. Obrigado e a equipe Mais Amor Cuidadores entrará em contato!");
				echo json_encode($dados);
			};
		}
	} else {
		$dados = array('mensage' => "Não foi possível inserir os dados! Tente novamente mais tarde.");
		echo json_encode($dados);
	};






















