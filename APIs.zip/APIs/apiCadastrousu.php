<?php
header("Access-Control-Allow-Origin:*");
header("Content-Type: application/html; charset=UTF-8");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

setlocale(LC_ALL,'pt_BR.UTF8');
mb_internal_encoding('UTF8'); 
mb_regex_encoding('UTF8');

include("apiBcrypt.php");



    //formulário

	$data = file_get_contents("php://input");
	$objData = json_decode($data);

    // TRANSFORMA O S DADOS

	$nome = $objData->nome;
	$email = $objData->email;
	$senha = $objData->senha;



    // LIMPA OS DADOS

	$nome = stripslashes($nome);
	$email = stripslashes($email);
	$senha = stripslashes($senha);


	$nome = trim($nome);
	$email = trim($email);
	$senha = trim($senha);

	$hash = Bcrypt::hash($senha);

    // INSERE OS DADOS
	$db = new PDO("mysql:host=localhost;dbname=maisa613_site;charset=utf8", "maisa613_app", "EqS?eeOlSkyT");
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	$result = array();
	
	if($db){
		$stmt=$db->prepare("SELECT email FROM tb_usu WHERE email='".$email."'");
		$stmt->execute();
		$stmt->setFetchMode(PDO::FETCH_ASSOC); 
		$result = $stmt->fetchAll();
		
	
		if(empty($result)){
		
        	$sql = "INSERT INTO tb_usu (nome, email, senha) VALUES ('".$nome."', '".$email."', '".$hash."')";
	        if ($nome!=''){
			$query = $db->prepare($sql);
			$query ->execute();
			if(!$query){
				$dados = array('mensage' => "Não foi possivel enviar os dados");
				echo json_encode($dados);
			} else {
				$dados = array('mensage' => "Os dados foram inseridos com sucesso. Obrigado e bem vindo.");
				echo json_encode($dados);
			};
		}
		
		} else {
			$dados = array('mensage' => "Você já é cadastrado, caso tenha esquecido a senha clique em 'Esqueceu sua senha?' na aba de entrar.");
			echo json_encode($dados);
		}
		
		
		
		
		
	} else {
    		$dados = array('mensage' => "Não foi possível inserir os dados! Tente novamente mais tarde.");
	    	echo json_encode($dados);
	};