<?php
header("Access-Control-Allow-Origin:*");
header("Content-Type: application/html; charset=UTF-8");

setlocale(LC_ALL,'pt_BR.UTF8');
mb_internal_encoding('UTF8'); 
mb_regex_encoding('UTF8');

    //formulário

    $data = file_get_contents("php://input");
    $objData = json_decode($data);

    // TRANSFORMA OS DADOS
    
    $nome = $objData->nome;
    $email = $objData->email;
    $telefone = $objData->telefone;

    $criancas = $objData->criancas;
    $adultos = $objData->adultos;
    $idosos = $objData->idosos;

    $manha = $objData->manha;
    $tarde = $objData->tarde;
    $noite = $objData->noite;
    $integral = $objData->integral;

    $escolha1 = $objData->escolha1;

    $escolha2 = $objData->escolha2;
    $formacao = $objData->formacao;

    $escolha3 = $objData->escolha3;
    $instituicao = $objData->instituicao;

    $escolha4 = $objData->escolha4;
    $empresa = $objData->empresa;


    // LIMPA OS DADOS

    $nome = stripslashes($nome);
    $email = stripslashes($email);
    $telefone = stripslashes($telefone);
    $criancas = stripslashes($criancas);
    $adultos = stripslashes($adultos);
    $idosos = stripslashes($idosos);
    $manha = stripslashes($manha);
    $tarde = stripslashes($tarde);
    $noite = stripslashes($noite);
    $integral = stripslashes($integral);
    $escolha1 = stripslashes($escolha1);
    $escolha2 = stripslashes($escolha2);
    $formacao = stripslashes($formacao);
    $escolha3 = stripslashes($escolha3);
    $instituicao = stripslashes($instituicao);
    $escolha4 = stripslashes($escolha4);
    $empresa = stripslashes($empresa);

    $nome = trim($nome);
    $email = trim($email);
    $telefone = trim($telefone);
    $criancas = trim($criancas);
    $adultos = trim($adultos);
    $idosos = trim($idosos);
    $manha = trim($manha);
    $tarde = trim($tarde);
    $noite = trim($noite);
    $integral = trim($integral);
    $escolha1 = trim($escolha1);
    $escolha2 = trim($escolha2);
    $formacao = trim($formacao);
    $escolha3 = trim($escolha3);
    $instituicao = trim($instituicao);
    $escolha4 = trim($escolha4);
    $empresa = trim($empresa);
    
    $deseja = "";
    if (($criancas != "") and ($adultos != "") and ($idosos != "")){
        $deseja = $criancas.", ".$adultos.", ".$idosos.".";
    } else if (($criancas != "") and ($adultos != "")){
        $deseja = $criancas.", ".$adultos.".";
    } else if (($adultos != "") and ($idosos != "")){
        $deseja = $adultos.", ".$idosos.".";
    } else if (($criancas != "") and ($idosos != "")){
        $deseja = $criancas.", ".$idosos.".";
    } else if (($criancas != "")){
        $deseja = $criancas.".";
    } else if (($adultos != "")){
        $deseja = $adultos.".";
    } else if (($idosos != "")){
        $deseja = $idosos.".";
    } else{
        $deseja = "Inválido";
    };


    $horario = "";
    if (($manha != "") and ($tarde != "") and ($noite != "") and ($integral != "")){
	$horario = $manha.", ".$tarde.", ".$noite.", ".$integral.".";
    } else if (($manha != "") and ($tarde != "") and ($noite != "")){
	$horario = $manha.", ".$tarde.", ".$noite.".";
    } else if (($manha != "") and ($tarde != "") and ($integral != "")){
	$horario = $manha.", ".$tarde.", ".$integral.".";
    } else if (($manha != "") and ($noite != "") and ($integral != "")){
	$horario = $manha.", ".$noite.", ".$integral.".";
    } else if (($tarde != "") and ($noite != "") and ($integral != "")){
	$horario = $tarde.", ".$noite.", ".$integral.".";
    } else if (($manha != "") and ($tarde != "")){
	$horario = $manha.", ".$tarde.".";
    } else if (($manha != "") and ($noite != "")){
	$horario = $manha.", ".$noite.".";
    } else if (($manha != "") and ($integral != "")){
	$horario = $manha.", ".$integral.".";
    } else if (($tarde != "") and ($noite != "")){
	$horario = $tarde.", ".$noite.".";
    } else if (($tarde != "") and ($integral != "")){
	$horario = $tarde.", ".$integral.".";
    } else if (($noite != "") and ($integral != "")){
	$horario = $noite.", ".$integral.".";
    } else if (($manha != "")){
	$horario = $manha.".";
    } else if (($tarde != "")){
	$horario = $tarde.".";
    } else if (($noite != "")){
	$horario = $noite.".";
    } else if (($integral != "")){
	$horario = $integral.".";
    } else{
        $horario = "Inválido";
    };






    // INSERE OS DADOS
    $db = new PDO("mysql:host=localhost;dbname=maisa613_site;charset=utf8", "maisa613_app", "EqS?eeOlSkyT");

    if($db){
        
        $sql = "INSERT INTO cadastro_cuidadores (nome, email, telefone, deseja, experiencia, horario, formacao, formacao_txt, curso, instituicao, exp_cuidador, empresa_exp) VALUES ('".$nome."', '".$email."', '".$telefone."', '".$deseja."', '".$escolha1."', '".$horario."', '".$escolha2."', '".$formacao."', '".$escolha3."', '".$instituicao."', '".$escolha4."', '".$empresa."')";
        
        
	$query = $db->prepare($sql);
	$query ->execute();
	echo "O seus dados foram enviados com sucesso. Obrigado e a equipe Mais Amor Cuidadores entrará em contato!";

    }else{
        echo "Não foi possível inserir os dados! Tente novamente mais tarde.";
    };
