<?php
header("Access-Control-Allow-Origin:*");
header("Content-Type: application/html; charset=UTF-8");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

setlocale(LC_ALL,'pt_BR.UTF8');
mb_internal_encoding('UTF8'); 
mb_regex_encoding('UTF8');

    //formulário

    $data = file_get_contents("php://input");
    $objData = json_decode($data);

    // TRANSFORMA OS DADOS
    
    $idservico = $objData->idservico;
    $satisfacao = $objData->satisfacao;
    $avaliacao = $objData->avaliacao;

    // LIMPA OS DADOS

    $idservico = stripslashes($idservico);
    $satisfacao = stripslashes($satisfacao);
    $avaliacao = stripslashes($avaliacao);


    $idservico = trim($idservico);
    $satisfacao = trim($satisfacao);
    $avaliacao = trim($avaliacao);


    // INSERE OS DADOS
	$db = new PDO("mysql:host=localhost;dbname=maisa613_site;charset=utf8", "maisa613_app", "EqS?eeOlSkyT");

	if($db){
		if ($idservico != 0){
			$sql = "INSERT INTO tb_avaliacao (id_solicitacao, comentario, avaliacao) VALUES ('".$idservico."', '".$avaliacao."', '".$satisfacao."')";
			$query = $db->prepare($sql);
			$query ->execute();
			if(!$query){
				$dados = array('mensage' => "Não foi possível enviar os dados.");
				echo json_encode($dados);
			} else {
				$dados = array('mensage' => "A sua avaliação foi resgistrada com sucesso. Obrigado por ajudar a melhorar nossos serviços.");
				echo json_encode($dados);
			};
		}
	} else {
		$dados = array('mensage' => "Não foi possível enviar os dados! Tente novamente mais tarde.");
		echo json_encode($dados);
	};






















