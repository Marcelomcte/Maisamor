<?php
header("Access-Control-Allow-Origin: *");
header('Content-Type: text/html; charset=utf-8');
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

setlocale(LC_ALL,'pt_BR.UTF8');
mb_internal_encoding('UTF8'); 
mb_regex_encoding('UTF8');


$data = file_get_contents("php://input");
$objData = json_decode($data);


$dns = 'mysql:host=localhost;dbname=maisa613_site;charset=utf8';
$user = 'maisa613_app';
$pass = 'EqS?eeOlSkyT';



$identifica = $objData->identifica;


try {	
	$con = new PDO($dns, $user, $pass);

	if(!$con){
		echo "Não foi possível conectar com Banco de Dados!";
	}

		
	$query = $con->prepare("SELECT * FROM tb_solicitacao_servicos WHERE id_requerente=".$identifica." AND cancelado!='Y'");

		$query->execute();

		$out = "[";

		while($result = $query->fetch()){
			
		
			$date = new DateTime($result["data_pedido"]);
			$datajunta = $date->format('d-m-Y H:i:s');
			
			
			
			if ($out != "[") {
				$out .= ",";
			}
			$out .= '{"Id": "'.$result["Id"].'",';
			$out .= '"data_pedido": "'.$result["data_pedido"].'",';
			$out .= '"id_requerente": "'.$result["id_requerente"].'",';
			$out .= '"email": "'.$result["email"].'",';
	            	$out .= '"servico_solicitado": "'.$result["servico_solicitado"].'",';
			$out .= '"nome_paciente": "'.$result["nome_paciente"].'",';
			$out .= '"nascimento": "'.$result["nascimento"].'",';
			$out .= '"genero": "'.$result["genero"].'",';
			$out .= '"diagnostico": "'.$result["diagnostico"].'",';
			$out .= '"deambulacao": "'.$result["deambulacao"].'",';
			$out .= '"alimentacao": "'.$result["alimentacao"].'",';
			$out .= '"perfil_paciente": "'.$result["perfil_paciente"].'",';
			$out .= '"perfil_cuidador": "'.$result["perfil_cuidador"].'",';
			$out .= '"interditado": "'.$result["interditado"].'",';
			$out .= '"local": "'.$result["local"].'",';
			$out .= '"ponto": "'.$result["ponto"].'",';
			$out .= '"datajunta": "'.$datajunta.'",';
			$out .= '"comentarios": "'.$result["comentarios"].'"}';
		}
		$out .= "]";
		echo $out;
	
	

} catch (Exception $e) {
	echo "Erro: ". $e->getMessage();
};